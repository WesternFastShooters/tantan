import { useState } from "react";
import type { ReactNode } from "react";
import {
  Search, Sparkles, Home, BookOpen, Settings, ChevronLeft,
  Bookmark, MoreHorizontal, Play, Star, X, Edit2, ChevronRight,
  ChevronDown, ChevronUp, Rss, User,
} from "lucide-react";

// ─── Design tokens ────────────────────────────────────────────────────────────
const BG = "#08090B";
const SURFACE = "#17181B";
const SURFACE2 = "#1E1F23";
const ACCENT = "#FF5A00";
const TEXT = "#F0F0F2";
const MUTED = "#9898A6";
const DIM = "#4E4E5A";
const BORDER = "rgba(255,255,255,0.07)";

const DEFAULT_TABS = ["推荐", "AI", "Web3", "3D", "时事政治", "前端", "Agent"];
const FILTERED_TABS = ["推荐", "Claude Code", "Codex", "Agent", "工作流", "源码分析"];

// ─── Types ────────────────────────────────────────────────────────────────────
type Scr = "home" | "search" | "subs" | "src-detail" | "settings" | "article";
type AIMode = "default" | "filtered";
type SubTab = "文章" | "帖子" | "图片" | "视频";

interface Card {
  id: string;
  kind: "article" | "post" | "video";
  title: string;
  excerpt?: string;
  src: string;
  srcInit: string;
  srcColor: string;
  time: string;
  hasImg: boolean;
  isVideo?: boolean;
  unread: boolean;
  zh?: string;
  orig?: string;
  translated?: boolean;
  img?: string;
}

interface SrcItem { name: string; init: string; color: string; unread: boolean; }
interface SrcGroup { id: string; label: string; count: number; items: SrcItem[]; }

// ─── Feed data ────────────────────────────────────────────────────────────────
const D_CARDS: Card[] = [
  {
    id: "d1", kind: "article",
    title: "OpenAI 发布新一代模型 GPT-5：更强推理与更低幻觉",
    src: "机器之心", srcInit: "机", srcColor: "#3B82F6",
    time: "2h", hasImg: true, unread: true, img: "robot",
    zh: "OpenAI 今日正式发布 GPT-5，这是迄今为止最强大的语言模型。新模型在推理能力上有了显著提升，幻觉率降低了 40%。GPT-5 采用全新架构，支持更长上下文，并在代码生成、数学推理等任务上达到新 SOTA 水平。\n\n根据内部基准测试，GPT-5 在 MMLU 上得分达到 92.3，超越此前所有公开模型。OpenAI CEO Sam Altman 表示，这是通往 AGI 道路上的重要里程碑。",
    orig: "OpenAI officially launched GPT-5, the most powerful language model to date. Reasoning improved significantly with 40% less hallucination. New architecture supports longer context windows with state-of-the-art results in code and math benchmarks. The MMLU score reached 92.3, surpassing all prior public models.",
    translated: false,
  },
  {
    id: "d2", kind: "article",
    title: "用 Three.js 打造一个赛博朋克迷你场景",
    src: "Cody 阿玉", srcInit: "C", srcColor: "#8B5CF6",
    time: "3h", hasImg: true, unread: true, img: "threejs",
    zh: "本文将带你一步步构建一个赛博朋克风格的 Three.js 3D 场景。我们将使用 WebGL 着色器创建霓虹灯效果，并实现基本粒子系统模拟雨滴效果。\n\n技术栈：Three.js 0.163、GLSL 着色器、WebGL 2.0。场景包含约 50,000 个多边形，中端设备仍能保持 60fps 流畅帧率。",
    orig: "Build a cyberpunk-style 3D scene with Three.js using WebGL shaders for neon lighting and a particle system simulating rain. The scene contains ~50k polygons maintaining 60fps on mid-range devices. Tech stack: Three.js 0.163, GLSL shaders, WebGL 2.0.",
    translated: true,
  },
  {
    id: "d3", kind: "article",
    title: "全球 AI 投资趋势（2020-2024）：谁在主导下一波浪潮",
    src: "CB Insights", srcInit: "CB", srcColor: "#10B981",
    time: "5h", hasImg: true, unread: true, img: "chart",
    zh: "全球 AI 投资在 2023 年达到 2500 亿美元峰值后，2024 年继续保持强劲增长。美国占全球 AI 投资的 45%，中国位居第二。基础模型公司获得最多资金，其次是 AI 基础设施和应用层。",
    orig: "Global AI investment peaked at $250B in 2023 with continued strong growth in 2024. The US holds 45% of global AI investment, followed by China. Foundation model companies receive the most funding.",
    translated: true,
  },
  {
    id: "d4", kind: "post",
    title: "终于搞懂了 React Server Components 和 Server Actions 的区别",
    excerpt: "RSC 是在服务器渲染的组件树，不发送 JS 到客户端。SA 是从客户端触发的服务器函数...",
    src: "Reddit r/reactjs", srcInit: "R", srcColor: "#FF4500",
    time: "1h", hasImg: false, unread: false,
    zh: "RSC = 服务器渲染的组件树，零 JS 发送到客户端。SA = 从客户端触发的服务器函数。\n\n关键区别：RSC 不能用 useState/useEffect；SA 需要 \"use server\" 指令。两者配合：RSC 渲染数据，SA 处理表单提交和变更操作。实际工程中，两者组合极大减少了 JS bundle 体积。",
    orig: "RSC = component trees rendered on server, zero JS to client. SA = server functions triggered from the client. Key: RSC can't use useState/useEffect; SA needs 'use server' directive. In practice, combining both significantly reduces JS bundle size.",
    translated: true,
  },
  {
    id: "d5", kind: "video",
    title: "Sora 最新视频生成演示：一致性与细节有了质的飞跃",
    src: "OpenAI", srcInit: "O", srcColor: "#06B6D4",
    time: "6h", hasImg: true, isVideo: true, unread: true, img: "dark-video",
    zh: "OpenAI 发布 Sora 最新演示，展示显著改进的时间一致性和物理模拟能力。新版本能生成长达 60 秒的连贯视频，人物和物体运动更加自然，场景转换无缝，光影效果逼真。",
    orig: "OpenAI releases latest Sora demonstrations showcasing dramatically improved temporal consistency and physics simulation. Generates coherent 60-second videos with natural motion and seamless transitions.",
    translated: false,
  },
  {
    id: "d6", kind: "article",
    title: "CSS Anchor Positioning：彻底告别 JavaScript 定位计算",
    src: "Adam Argyle", srcInit: "AA", srcColor: "#F59E0B",
    time: "8h", hasImg: true, unread: false, img: "css-code",
    zh: "CSS Anchor Positioning 是革命性的新 CSS 特性，允许将一个元素的位置锚定到另一个元素，完全不需要 JavaScript。这对 tooltip、popover 和下拉菜单的实现有重大影响。\n\n浏览器支持：Chrome 125+ 已支持，Firefox 和 Safari 也在积极实现中。",
    orig: "CSS Anchor Positioning is a revolutionary new feature letting you anchor one element's position to another entirely in CSS — no JS needed. Huge implications for tooltips and popovers. Chrome 125+ already supports it.",
    translated: true,
  },
];

const F_CARDS: Card[] = [
  {
    id: "f1", kind: "article",
    title: "Claude Code 深度实践：构建可持续迭代的 AI 编程工作流",
    src: "Simon Willison", srcInit: "SW", srcColor: "#3B82F6",
    time: "6h", hasImg: true, unread: true, img: "claude-term",
    zh: "Simon Willison 分享了使用 Claude Code 进行 AI 辅助编程的深度实践经验，详细介绍了如何构建可持续迭代的工作流，包括上下文管理、工具调用最佳实践和常见陷阱规避。\n\n核心洞见：将 Claude Code 视为配对程序员而非代码补全工具，主动提供背景信息，定期回顾并调整 AI 的工作方向。实测效率提升约 3x。",
    orig: "Simon Willison shares his deep practice with Claude Code for AI-assisted programming, detailing how to build a sustainable iterative workflow with context management and tool-use best practices. Core insight: treat Claude Code as a pair programmer, not a code completion tool. Measured 3x productivity gains.",
    translated: true,
  },
  {
    id: "f2", kind: "article",
    title: "深入 Codex：原理、能力边界与真实工程落地经验",
    src: "Latent Space", srcInit: "LS", srcColor: "#8B5CF6",
    time: "8h", hasImg: true, unread: true, img: "codex-box",
    zh: "Latent Space 团队深度剖析 OpenAI Codex，涵盖底层原理、实际能力边界及真实工程场景落地经验。文章包含大量代码示例和基准测试结果。\n\nCodex 在纯代码任务上仍然出色，但在复杂系统设计和跨文件理解上仍有提升空间。最佳实践：分解任务，提供明确上下文。",
    orig: "Latent Space provides an in-depth analysis of OpenAI Codex covering its principles, capability limits, and real-world engineering implementation with extensive benchmarks. Codex excels at isolated code tasks but still has room for improvement in cross-file understanding.",
    translated: true,
  },
  {
    id: "f3", kind: "article",
    title: "Agent Harness 1.0 发布：为 AI Agent 构建可靠评测与观测",
    src: "Agent Harness Blog", srcInit: "AH", srcColor: "#F59E0B",
    time: "12h", hasImg: true, unread: true, img: "agent-h",
    zh: "Agent Harness 正式发布 1.0 版本，这是专为 AI Agent 设计的评测和观测框架。新版本支持多种主流 Agent 框架，提供细粒度步骤追踪、工具调用记录和性能指标统计。\n\n关键特性：沙箱环境隔离、工具调用重放、基于自然语言的评测标准定义。支持 Claude、GPT-4 等主流模型。",
    orig: "Agent Harness officially releases version 1.0, an evaluation and observability framework for AI agents. Supports major agent frameworks with fine-grained step tracking, tool call logging, and performance metrics. Key features: sandbox isolation, tool call replay, natural language evaluation criteria.",
    translated: false,
  },
  {
    id: "f4", kind: "article",
    title: "如何用 Claude Code + Codex 协同完成复杂项目的全流程开发",
    src: "Beyond the Prompt", srcInit: "BP", srcColor: "#10B981",
    time: "14h", hasImg: true, unread: true, img: "flow",
    zh: "本文探讨如何将 Claude Code 和 Codex 结合，在复杂项目中实现 Plan → Code → Test → Review 的完整开发循环。通过真实 SaaS 项目案例，详细说明两个工具的分工方式。\n\nClaude Code 擅长架构设计和复杂逻辑，Codex 擅长快速生成样板代码和单元测试，两者互补显著提升开发效率。",
    orig: "Exploring how to combine Claude Code and Codex for complex projects implementing a complete Plan → Code → Test → Review development cycle via a real SaaS case study. Claude Code handles architecture; Codex handles boilerplate and unit tests.",
    translated: true,
  },
  {
    id: "f5", kind: "article",
    title: "源码解析：Claude Code 的会话管理、工具调用与上下文压缩",
    src: "Reading the Source", srcInit: "RS", srcColor: "#EF4444",
    time: "1d", hasImg: true, unread: false, img: "src-code",
    zh: "深入分析 Claude Code 内部源码，揭示会话状态管理机制、工具调用协议实现及上下文压缩算法。\n\n会话管理采用混合方式结合本地状态和服务端持久化。工具调用通过标准 JSON-RPC 协议实现，支持并行调用和错误恢复。",
    orig: "Deep analysis of Claude Code's source code revealing session state management, tool call protocol implementation, and context compression algorithm. Sessions use hybrid local+server persistence. Tool calls use JSON-RPC with parallel support.",
    translated: false,
  },
  {
    id: "f6", kind: "article",
    title: "AI 工具一周速递：Claude Code 更新、Codex 新功能与生态动态",
    src: "AI 工具观察", srcInit: "AI", srcColor: "#06B6D4",
    time: "1d", hasImg: true, unread: false, img: "news",
    zh: "本周 AI 工具圈重大动态：Claude Code 推出并行工具调用特性；Codex 更新沙箱环境；Agent Harness 发布 1.0；多个基于这些工具的开源项目值得关注。\n\n社区围绕 Claude Code + Codex 协作模式的讨论越来越多，形成了若干最佳实践模式。",
    orig: "Weekly AI tools digest: Claude Code launches parallel tool calling, Codex updates sandbox, Agent Harness releases 1.0, plus notable open source projects. Community discussion around Claude Code + Codex collaboration patterns is growing.",
    translated: false,
  },
];

const SRC_GROUPS: SrcGroup[] = [
  {
    id: "x", label: "X.com", count: 6,
    items: [
      { name: "Twitter @孙宇晨（去过太空版）", init: "孙", color: "#F59E0B", unread: true },
      { name: "Twitter @Andrej Karpathy", init: "AK", color: "#3B82F6", unread: true },
      { name: "Twitter @Elon Musk", init: "EM", color: "#6B7280", unread: false },
      { name: "Twitter @Hamel Husain", init: "HH", color: "#10B981", unread: true },
      { name: "Twitter @Thariq", init: "T", color: "#8B5CF6", unread: false },
      { name: "Twitter @Tibo", init: "TB", color: "#EF4444", unread: false },
    ],
  },
  {
    id: "blogs", label: "Blogs", count: 5,
    items: [
      { name: "Adam Argyle", init: "AA", color: "#F59E0B", unread: true },
      { name: "AddyOsmani.com", init: "AO", color: "#3B82F6", unread: false },
      { name: "Armin Ronacher's Thoughts and Writings", init: "AR", color: "#10B981", unread: false },
      { name: "Bram.us", init: "B", color: "#8B5CF6", unread: false },
      { name: "Swyx — Thinking on Systems", init: "SW", color: "#EF4444", unread: true },
    ],
  },
  {
    id: "ai", label: "AI", count: 4,
    items: [
      { name: "Latent Space", init: "LS", color: "#8B5CF6", unread: true },
      { name: "Simon Willison", init: "SW", color: "#3B82F6", unread: true },
      { name: "Reading the Source", init: "RS", color: "#EF4444", unread: false },
      { name: "AI 工具观察", init: "AI", color: "#06B6D4", unread: true },
    ],
  },
  {
    id: "yt", label: "YouTube", count: 3,
    items: [
      { name: "Fireship", init: "F", color: "#EF4444", unread: true },
      { name: "Theo — t3.gg", init: "T3", color: "#8B5CF6", unread: false },
      { name: "Primeagen", init: "PG", color: "#10B981", unread: true },
    ],
  },
];

// ─── Atom components ──────────────────────────────────────────────────────────
function Av({ init, color, size = 24 }: { init: string; color: string; size?: number }) {
  return (
    <div className="rounded-full flex items-center justify-center flex-shrink-0"
      style={{ width: size, height: size, background: color + "28", border: `1px solid ${color}50` }}>
      <span style={{ fontSize: size * 0.37, color, fontWeight: 700, lineHeight: 1 }}>{init}</span>
    </div>
  );
}

function Toggle({ on, onToggle }: { on: boolean; onToggle: () => void }) {
  return (
    <button onClick={onToggle}
      className="relative rounded-full flex-shrink-0"
      style={{ width: 44, height: 24, background: on ? ACCENT : "#38383E", transition: "background 0.2s" }}>
      <div className="absolute top-[2px] w-5 h-5 bg-white rounded-full shadow"
        style={{ left: on ? 22 : 2, transition: "left 0.18s" }} />
    </button>
  );
}

// ─── Card image renderers ─────────────────────────────────────────────────────
function CardImg({ img, unread, h = 144 }: { img?: string; unread: boolean; h?: number }) {
  const dot = unread ? (
    <div className="absolute top-2 right-2 rounded-full" style={{ width: 7, height: 7, background: ACCENT }} />
  ) : null;

  if (img === "robot") return (
    <div className="w-full rounded-xl overflow-hidden relative" style={{ height: h, background: "linear-gradient(155deg,#0e1828 0%,#1c0930 55%,#050810 100%)" }}>
      {dot}
      <div className="absolute bottom-5 left-1/2 -translate-x-1/2 opacity-35">
        <div style={{ width: 46, height: 54, borderRadius: "50% 50% 22% 22%", border: "1.5px solid rgba(110,150,255,0.55)", background: "rgba(70,110,200,0.12)" }} />
      </div>
      {([12, 8, 30, 18, 68, 12, 54, 33, 84, 7, 42, 5] as number[]).reduce<[number, number][]>((acc, v, i) => {
        if (i % 2 === 0) acc.push([v, 0]); else acc[acc.length - 1][1] = v;
        return acc;
      }, []).map(([l, t], i) => (
        <div key={i} className="absolute bg-white rounded-full"
          style={{ left: `${l}%`, top: `${t}%`, width: i < 2 ? 2 : 1, height: i < 2 ? 2 : 1, opacity: 0.38 }} />
      ))}
    </div>
  );

  if (img === "threejs") return (
    <div className="w-full rounded-xl overflow-hidden relative" style={{ height: h, background: "linear-gradient(135deg,#0a1525 0%,#192a3e 55%,#080d18 100%)" }}>
      {dot}
      <div className="absolute inset-0 flex items-center justify-center">
        <div style={{ width: 84, height: 62, background: "rgba(28,72,140,0.2)", border: "1px solid rgba(55,130,220,0.35)", borderRadius: 8, transform: "perspective(110px) rotateX(9deg) rotateY(-11deg)" }}>
          <div style={{ height: 1.5, background: "rgba(55,130,220,0.45)", margin: "10px 8px 0" }} />
          <div style={{ height: 1.5, background: "rgba(55,130,220,0.28)", margin: "8px 18px 0 8px" }} />
          <div style={{ height: 1.5, background: "rgba(55,130,220,0.16)", margin: "8px 28px 0 8px" }} />
        </div>
      </div>
    </div>
  );

  if (img === "chart") return (
    <div className="w-full rounded-xl overflow-hidden relative" style={{ height: h * 0.82, background: "#0c1410" }}>
      {dot}
      <div className="absolute inset-0 p-3 flex items-end gap-1.5">
        {[34, 47, 41, 59, 54, 77, 67, 90].map((v, i) => (
          <div key={i} className="flex-1 rounded-sm" style={{ height: `${v}%`, background: i === 7 ? ACCENT + "CC" : `rgba(255,90,0,${0.17 + i * 0.065})` }} />
        ))}
      </div>
    </div>
  );

  if (img === "dark-video") return (
    <div className="w-full rounded-xl overflow-hidden relative" style={{ height: h, background: "linear-gradient(135deg,#09101e 0%,#100b22 60%,#06060f 100%)" }}>
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="flex items-center justify-center rounded-full"
          style={{ width: 40, height: 40, background: "rgba(255,255,255,0.15)", backdropFilter: "blur(4px)" }}>
          <Play size={16} fill="white" color="white" style={{ marginLeft: 2 }} />
        </div>
      </div>
      {dot}
    </div>
  );

  if (img === "css-code") return (
    <div className="w-full rounded-xl overflow-hidden relative" style={{ height: h * 0.88, background: "#0d1117" }}>
      <div className="absolute inset-0 p-3" style={{ fontFamily: "monospace" }}>
        <div style={{ color: "#ff7b72", fontSize: 8.5 }}>{"@position-anchor { --anchor: --btn; }"}</div>
        <div style={{ color: "#79c0ff", fontSize: 8.5, marginTop: 5 }}>{"[popover] {"}</div>
        <div style={{ color: "#a5d6ff", fontSize: 8.5, paddingLeft: 12 }}>{"position-anchor: --btn;"}</div>
        <div style={{ color: "#a5d6ff", fontSize: 8.5, paddingLeft: 12 }}>{"top: anchor(bottom);"}</div>
        <div style={{ color: "#79c0ff", fontSize: 8.5 }}>{"}"}</div>
      </div>
    </div>
  );

  if (img === "claude-term") return (
    <div className="w-full rounded-xl overflow-hidden relative" style={{ height: h, background: "#0d1117" }}>
      {dot}
      <div className="absolute inset-0 p-3" style={{ fontFamily: "monospace" }}>
        <div style={{ color: "#3fb950", fontSize: 11 }}>{">"}<span style={{ color: "#8b949e" }}>{"$ "}</span>{"claude"}</div>
        <div style={{ color: "#8b949e", fontSize: 9.5, marginTop: 4 }}>Welcome to Claude Code</div>
        <div style={{ color: "#30a14e", fontSize: 9, marginTop: 9 }}>{"│ "}<span style={{ color: "#c9d1d9" }}>Ready for instructions...</span></div>
        <div style={{ color: "#30a14e", fontSize: 9, marginTop: 3 }}>{"│ "}<span style={{ color: "#444c56" }}>Type your task or /help</span></div>
      </div>
    </div>
  );

  if (img === "codex-box") return (
    <div className="w-full rounded-xl overflow-hidden relative" style={{ height: h, background: "#0d1117" }}>
      {dot}
      <div className="absolute inset-0 p-3">
        <div style={{ color: "#e6edf3", fontSize: 15, fontWeight: 700 }}>Codex</div>
        <div style={{ color: "#8b949e", fontSize: 9.5, marginTop: 2 }}>Generating...</div>
        <div style={{ color: "#6e7681", fontSize: 8.5, marginTop: 11, fontFamily: "monospace" }}>Write a function to parse</div>
        <div style={{ color: "#6e7681", fontSize: 8.5, fontFamily: "monospace" }}>CSV and return summary</div>
        <div style={{ color: "#6e7681", fontSize: 8.5, fontFamily: "monospace" }}>statistics.</div>
      </div>
    </div>
  );

  if (img === "agent-h") return (
    <div className="w-full rounded-xl overflow-hidden relative" style={{ height: h * 0.88, background: "linear-gradient(135deg,#1a1005 0%,#251808 100%)" }}>
      {dot}
      <div className="absolute inset-0 p-3 flex flex-col">
        <div style={{ color: "#F59E0B", fontSize: 13, fontWeight: 700 }}>Agent Harness 🦜</div>
        <div style={{ color: "#7a6535", fontSize: 9.5, marginTop: 3 }}>v1.0 · Evaluation framework</div>
        <div className="mt-auto flex gap-1.5">
          {["Init", "Run", "Eval"].map((s, i) => (
            <div key={i} style={{ background: i < 2 ? "#F59E0B22" : "#252629", borderRadius: 4, padding: "2px 7px", fontSize: 8.5, color: i < 2 ? "#F59E0B" : "#5a5a68" }}>{s}</div>
          ))}
        </div>
      </div>
    </div>
  );

  if (img === "flow") return (
    <div className="w-full rounded-xl overflow-hidden relative" style={{ height: h * 0.88, background: "#0d1117" }}>
      {dot}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="flex items-center gap-1">
          {["Plan", "Code", "Test", "Review"].map((s, i) => (
            <div key={i} className="flex items-center gap-0.5">
              <div style={{ background: "#1c2333", border: "1px solid #2d3748", borderRadius: 4, padding: "4px 7px", fontSize: 8.5, color: "#8b949e" }}>{s}</div>
              {i < 3 && <span style={{ color: "#3d444d", fontSize: 9 }}>→</span>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  if (img === "src-code") return (
    <div className="w-full rounded-xl overflow-hidden relative" style={{ height: h, background: "#0d1117" }}>
      <div className="absolute inset-0 p-3" style={{ fontFamily: "monospace" }}>
        <div style={{ color: "#ff7b72", fontSize: 8.5 }}>{"async function handleTool("}</div>
        <div style={{ color: "#79c0ff", fontSize: 8.5, paddingLeft: 12 }}>{"call: ToolCall"}</div>
        <div style={{ color: "#ff7b72", fontSize: 8.5 }}>{") : Promise<Result> {"}</div>
        <div style={{ color: "#8b949e", fontSize: 8.5, paddingLeft: 12 }}>{"const res = await"}</div>
        <div style={{ color: "#79c0ff", fontSize: 8.5, paddingLeft: 20 }}>{"executor.run(call);"}</div>
        <div style={{ color: "#8b949e", fontSize: 8.5, paddingLeft: 12 }}>{"return compress(res);"}</div>
        <div style={{ color: "#ff7b72", fontSize: 8.5 }}>{"}"}</div>
      </div>
    </div>
  );

  if (img === "news") return (
    <div className="w-full rounded-xl overflow-hidden relative" style={{ height: h * 0.88, background: "linear-gradient(135deg,#080818 0%,#110f26 100%)" }}>
      <div className="absolute inset-0 flex items-center justify-center">
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: 16, fontWeight: 800, background: `linear-gradient(90deg,${ACCENT},#FF8C40)`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>Tooling News</div>
          <div style={{ color: "#3d3d50", fontSize: 9, marginTop: 3 }}>Weekly digest</div>
        </div>
      </div>
    </div>
  );

  return null;
}

// ─── Feed card ────────────────────────────────────────────────────────────────
function FeedCard({ card, onTap }: { card: Card; onTap: (c: Card) => void }) {
  return (
    <button onClick={() => onTap(card)}
      className="w-full text-left rounded-xl overflow-hidden mb-2.5"
      style={{ background: SURFACE, border: `1px solid ${BORDER}` }}>
      {card.hasImg && <CardImg img={card.img} unread={card.unread} />}
      <div className="px-2.5 pt-2 pb-2.5">
        {!card.hasImg && card.unread && (
          <div className="rounded-full ml-auto mb-1.5" style={{ width: 7, height: 7, background: ACCENT }} />
        )}
        <p className="leading-snug font-medium"
          style={{
            fontSize: 12.5, color: TEXT,
            display: "-webkit-box", WebkitLineClamp: card.hasImg ? 2 : 3,
            WebkitBoxOrient: "vertical", overflow: "hidden",
          }}>
          {card.title}
        </p>
        {card.excerpt && (
          <p className="mt-1 leading-snug"
            style={{ fontSize: 11, color: MUTED, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>
            {card.excerpt}
          </p>
        )}
        <div className="mt-2 flex items-center gap-1.5">
          <Av init={card.srcInit} color={card.srcColor} size={17} />
          <span className="flex-1 overflow-hidden" style={{ fontSize: 10.5, color: MUTED, textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{card.src}</span>
          <span style={{ fontSize: 10, color: DIM, flexShrink: 0 }}>{card.time}</span>
        </div>
      </div>
    </button>
  );
}

// ─── Two-column masonry ───────────────────────────────────────────────────────
function MasonryFeed({ cards, onTap }: { cards: Card[]; onTap: (c: Card) => void }) {
  const left = cards.filter((_, i) => i % 2 === 0);
  const right = cards.filter((_, i) => i % 2 !== 0);
  return (
    <div className="flex gap-2.5 px-3">
      <div className="flex flex-col flex-1">{left.map(c => <FeedCard key={c.id} card={c} onTap={onTap} />)}</div>
      <div className="flex flex-col flex-1" style={{ marginTop: 14 }}>{right.map(c => <FeedCard key={c.id} card={c} onTap={onTap} />)}</div>
    </div>
  );
}

// ─── Status bar ───────────────────────────────────────────────────────────────
function StatusBar() {
  return (
    <div className="flex items-center justify-between px-5 pt-3 pb-1 flex-shrink-0" style={{ fontSize: 14, color: TEXT, fontWeight: 600 }}>
      <span>9:41</span>
      <div className="flex items-center gap-1.5">
        <svg width="17" height="11" viewBox="0 0 17 11" fill="none">
          {[0, 1, 2, 3].map(i => <rect key={i} x={i * 4.2} y={10 - i * 2.5} width="3.2" height={i * 2.5 + 1} rx="0.6" fill="white" />)}
        </svg>
        <svg width="15" height="11" viewBox="0 0 15 11" fill="none">
          <circle cx="7.5" cy="9.5" r="1" fill="white" />
          <path d="M4.5 6.8C5.5 5.7 6.4 5.2 7.5 5.2s2 .5 3 1.6" stroke="white" strokeWidth="1.2" strokeLinecap="round" />
          <path d="M2 4C3.6 2.3 5.4 1.4 7.5 1.4s3.9.9 5.5 2.6" stroke="white" strokeWidth="1.2" strokeLinecap="round" />
        </svg>
        <div className="flex items-center gap-[2px]">
          <div className="rounded-[2px] border border-white/50 relative p-[1.5px]" style={{ width: 24, height: 12 }}>
            <div className="h-full w-5/6 rounded-[1px]" style={{ background: "white" }} />
          </div>
          <div className="rounded-sm bg-white/50" style={{ width: 1.5, height: 6 }} />
        </div>
      </div>
    </div>
  );
}

// ─── Bottom navigation ────────────────────────────────────────────────────────
type NavId = "home" | "subs" | "settings";
function BottomNav({ active, onChange }: { active: NavId; onChange: (s: NavId) => void }) {
  const items: { id: NavId; label: string; Icon: typeof Home }[] = [
    { id: "home", label: "首页", Icon: Home },
    { id: "subs", label: "订阅", Icon: BookOpen },
    { id: "settings", label: "设置", Icon: Settings },
  ];
  return (
    <div className="flex items-center flex-shrink-0" style={{ background: SURFACE, borderTop: `1px solid ${BORDER}`, paddingBottom: 10, paddingTop: 6 }}>
      {items.map(({ id, label, Icon }) => {
        const active_ = active === id;
        return (
          <button key={id} onClick={() => onChange(id)} className="flex-1 flex flex-col items-center gap-0.5" style={{ color: active_ ? ACCENT : DIM }}>
            <Icon size={22} strokeWidth={active_ ? 2.2 : 1.8} />
            <span style={{ fontSize: 10, fontWeight: active_ ? 600 : 400 }}>{label}</span>
          </button>
        );
      })}
    </div>
  );
}

// ─── Topic tabs ───────────────────────────────────────────────────────────────
function TopicTabs({ tabs, active, onChange }: { tabs: string[]; active: number; onChange: (i: number) => void }) {
  return (
    <div className="flex overflow-x-auto px-4 gap-5 flex-shrink-0"
      style={{ borderBottom: `1px solid ${BORDER}`, scrollbarWidth: "none" }}>
      {tabs.map((t, i) => (
        <button key={t} onClick={() => onChange(i)}
          className="relative flex-shrink-0 py-2.5"
          style={{ fontSize: 13.5, fontWeight: i === active ? 600 : 400, color: i === active ? ACCENT : MUTED }}>
          {t}
          {i === active && (
            <div className="absolute bottom-0 left-0 right-0 rounded-full" style={{ height: 2, background: ACCENT }} />
          )}
        </button>
      ))}
    </div>
  );
}

// ─── AI filter status bar ─────────────────────────────────────────────────────
function AIFilterBar({ onEdit, onReset }: { onEdit: () => void; onReset: () => void }) {
  return (
    <div className="px-4 pt-3 pb-2.5 flex-shrink-0" style={{ borderBottom: `1px solid ${BORDER}` }}>
      <div className="flex items-center gap-2 mb-2">
        <button onClick={onReset}
          className="flex items-center gap-1.5 px-3 py-1 rounded-full"
          style={{ background: ACCENT }}>
          <span style={{ fontSize: 12, fontWeight: 600, color: "white" }}>Claude Code × Codex</span>
          <X size={11} color="white" />
        </button>
      </div>
      <div className="flex items-center mb-0.5">
        <Sparkles size={13} style={{ color: ACCENT, marginRight: 5, flexShrink: 0 }} />
        <span className="flex-1" style={{ fontSize: 13, fontWeight: 600, color: TEXT }}>AI 智能筛选结果</span>
        <button onClick={onEdit} className="flex items-center gap-1" style={{ color: MUTED }}>
          <Edit2 size={12} />
          <span style={{ fontSize: 11.5 }}>编辑</span>
        </button>
      </div>
      <p style={{ fontSize: 11, color: DIM }}>近 7 天 · 未读 · 技术内容 · 已过滤融资/入门</p>
    </div>
  );
}

// ─── AI filter bottom sheet ───────────────────────────────────────────────────
function AIFilterSheet({ open, query, onQueryChange, onClose, onGenerate }: {
  open: boolean; query: string; onQueryChange: (q: string) => void;
  onClose: () => void; onGenerate: () => void;
}) {
  const chips = ["AI Agent", "3D 项目", "前端新技术", "只看英文一手来源", "过滤营销内容"];
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const toggle = (c: string) => setSelected(prev => { const s = new Set(prev); s.has(c) ? s.delete(c) : s.add(c); return s; });

  if (!open) return null;
  return (
    <div className="absolute inset-0 z-50 flex flex-col justify-end">
      <div className="absolute inset-0" style={{ background: "rgba(0,0,0,0.62)" }} onClick={onClose} />
      <div className="relative flex flex-col rounded-t-3xl overflow-hidden" style={{ background: SURFACE2, maxHeight: "60%" }}>
        <div className="flex justify-center pt-3 pb-1 flex-shrink-0">
          <div className="w-9 h-1 rounded-full" style={{ background: "#3a3b42" }} />
        </div>
        <div className="overflow-y-auto px-4 pb-6">
          <div className="flex items-center gap-2 mt-1 mb-1">
            <Sparkles size={16} style={{ color: ACCENT }} />
            <span style={{ fontSize: 16, fontWeight: 700, color: TEXT }}>AI 智能筛选</span>
          </div>
          <p style={{ fontSize: 12, color: MUTED, marginBottom: 12 }}>用自然语言描述你想看的内容，AI 将为你生成个性化信息流</p>
          <div className="rounded-xl p-3" style={{ background: SURFACE, border: `1px solid ${BORDER}` }}>
            <textarea
              value={query} onChange={e => onQueryChange(e.target.value)} maxLength={300} rows={4}
              className="w-full bg-transparent resize-none outline-none"
              style={{ fontSize: 13, color: TEXT, lineHeight: 1.55 }}
              placeholder="描述你想看的内容，例如：最近一周的 AI Agent 技术进展，不要融资新闻..." />
            <div className="flex justify-end" style={{ fontSize: 11, color: DIM }}>{query.length}/300</div>
          </div>
          <p style={{ fontSize: 13, fontWeight: 600, color: TEXT, margin: "14px 0 9px" }}>推荐主题</p>
          <div className="flex flex-wrap gap-2">
            {chips.map(chip => (
              <button key={chip} onClick={() => toggle(chip)}
                className="px-3 py-1.5 rounded-full"
                style={{
                  border: `1px solid ${selected.has(chip) ? ACCENT : BORDER}`,
                  background: selected.has(chip) ? ACCENT + "20" : "transparent",
                  fontSize: 12, color: selected.has(chip) ? ACCENT : MUTED,
                }}>
                {chip}
              </button>
            ))}
          </div>
          <div className="flex gap-3 mt-5">
            <button onClick={onClose}
              className="flex-1 py-3 rounded-xl font-semibold"
              style={{ background: SURFACE, fontSize: 15, color: MUTED }}>
              取消
            </button>
            <button onClick={onGenerate}
              className="flex-1 py-3 rounded-xl font-semibold flex items-center justify-center gap-2"
              style={{ background: ACCENT, fontSize: 15, color: "white" }}>
              <Sparkles size={15} />生成信息流
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Home screen ──────────────────────────────────────────────────────────────
function HomeScreen({ aiMode, aiQuery, activeTab, readIds, onAIFilter, onSearch, onCardTap, onTopicChange, onEdit, onReset }: {
  aiMode: AIMode; aiQuery: string; activeTab: number; readIds: Set<string>;
  onAIFilter: () => void; onSearch: () => void; onCardTap: (c: Card) => void;
  onTopicChange: (i: number) => void; onEdit: () => void; onReset: () => void;
}) {
  const tabs = aiMode === "filtered" ? FILTERED_TABS : DEFAULT_TABS;
  const allCards = aiMode === "filtered" ? F_CARDS : D_CARDS;
  const cards = allCards.filter(c => !readIds.has(c.id));

  return (
    <div className="flex flex-col h-full">
      <StatusBar />
      <div className="flex items-center px-4 pt-1 pb-3 flex-shrink-0 relative">
        <div className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: ACCENT + "22" }}>
          <Rss size={14} style={{ color: ACCENT }} />
        </div>
        <span className="absolute left-1/2 -translate-x-1/2" style={{ fontSize: 17, fontWeight: 700, color: TEXT }}>发现</span>
        <div className="flex items-center gap-3.5 ml-auto">
          <button onClick={onSearch}><Search size={20} style={{ color: TEXT }} /></button>
          <button onClick={onAIFilter}>
            <Sparkles size={20} style={{ color: aiMode === "filtered" ? ACCENT : TEXT }} />
          </button>
        </div>
      </div>
      <TopicTabs tabs={tabs} active={activeTab} onChange={onTopicChange} />
      {aiMode === "filtered" && <AIFilterBar onEdit={onEdit} onReset={onReset} />}
      <div className="flex-1 overflow-y-auto pt-3">
        {cards.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20" style={{ color: DIM }}>
            <Rss size={36} style={{ marginBottom: 12, opacity: 0.4 }} />
            <p style={{ fontSize: 14 }}>所有内容已读完</p>
          </div>
        ) : (
          <MasonryFeed cards={cards} onTap={onCardTap} />
        )}
      </div>
    </div>
  );
}

// ─── Search screen ────────────────────────────────────────────────────────────
function SearchScreen({ onBack }: { onBack: () => void }) {
  const [q, setQ] = useState("");
  const allCards = [...D_CARDS, ...F_CARDS];
  const results = q.length > 1 ? allCards.filter(c =>
    c.title.includes(q) || c.src.includes(q)
  ) : [];
  const hotTerms = ["Claude Code", "Agent Harness", "Codex", "React Server Components", "Three.js"];

  return (
    <div className="flex flex-col h-full">
      <StatusBar />
      <div className="flex items-center gap-3 px-4 pt-2 pb-3 flex-shrink-0">
        <button onClick={onBack}><ChevronLeft size={24} style={{ color: TEXT }} /></button>
        <div className="flex-1 flex items-center rounded-xl px-3 py-2.5 gap-2" style={{ background: SURFACE }}>
          <Search size={15} style={{ color: MUTED }} />
          <input className="flex-1 bg-transparent outline-none" style={{ fontSize: 14, color: TEXT }}
            placeholder="搜索文章、帖子、来源、Topic…"
            value={q} onChange={e => setQ(e.target.value)} autoFocus />
          {q && <button onClick={() => setQ("")}><X size={14} style={{ color: MUTED }} /></button>}
        </div>
      </div>
      <div className="flex-1 overflow-y-auto px-4">
        {q.length <= 1 && (
          <>
            <p className="mb-3" style={{ fontSize: 12, color: DIM, fontWeight: 500 }}>热门搜索</p>
            {hotTerms.map(s => (
              <button key={s} onClick={() => setQ(s)}
                className="w-full flex items-center gap-3 py-3.5"
                style={{ borderBottom: `1px solid ${BORDER}` }}>
                <Search size={14} style={{ color: DIM }} />
                <span style={{ fontSize: 14, color: MUTED }}>{s}</span>
              </button>
            ))}
          </>
        )}
        {q.length > 1 && results.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20">
            <Search size={34} style={{ color: DIM, opacity: 0.5, marginBottom: 12 }} />
            <p style={{ fontSize: 14, color: MUTED }}>没有找到"{q}"相关内容</p>
            <p style={{ fontSize: 12, color: DIM, marginTop: 4 }}>搜索结果包含已读内容</p>
          </div>
        )}
        {results.map(c => (
          <div key={c.id} className="py-3.5" style={{ borderBottom: `1px solid ${BORDER}` }}>
            <p className="mb-1.5" style={{ fontSize: 13.5, fontWeight: 500, color: TEXT }}>{c.title}</p>
            <div className="flex items-center gap-2">
              <Av init={c.srcInit} color={c.srcColor} size={16} />
              <span style={{ fontSize: 11, color: MUTED }}>{c.src}</span>
              <span style={{ fontSize: 11, color: DIM }}>·</span>
              <span style={{ fontSize: 11, color: DIM }}>{c.time}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Subscriptions screen ─────────────────────────────────────────────────────
function SubsScreen({ onSrcTap }: { onSrcTap: (g: SrcGroup) => void }) {
  const [subTab, setSubTab] = useState<SubTab>("文章");
  const [expanded, setExpanded] = useState<Set<string>>(new Set(["x", "blogs"]));
  const SUB_TABS: SubTab[] = ["文章", "帖子", "图片", "视频"];
  const toggle = (id: string) => setExpanded(prev => { const s = new Set(prev); s.has(id) ? s.delete(id) : s.add(id); return s; });

  return (
    <div className="flex flex-col h-full">
      <StatusBar />
      <div className="flex items-center px-4 pt-1 pb-3 flex-shrink-0 relative">
        <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: "#3B82F6" }}>
          <User size={15} color="white" />
        </div>
        <span className="absolute left-1/2 -translate-x-1/2" style={{ fontSize: 17, fontWeight: 700, color: TEXT }}>订阅</span>
        <button className="ml-auto"><MoreHorizontal size={22} style={{ color: TEXT }} /></button>
      </div>
      {/* Content type selector */}
      <div className="flex px-4 gap-2 pb-3 flex-shrink-0">
        {SUB_TABS.map(t => (
          <button key={t} onClick={() => setSubTab(t)} className="px-3.5 py-1.5 rounded-lg"
            style={{ background: t === subTab ? ACCENT : SURFACE2, fontSize: 13, fontWeight: t === subTab ? 600 : 400, color: t === subTab ? "white" : MUTED }}>
            {t}
          </button>
        ))}
      </div>
      <div className="flex-1 overflow-y-auto px-4">
        {/* Favorites */}
        <div className="rounded-xl p-3 mb-3 flex items-center gap-3" style={{ background: SURFACE }}>
          <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: "#F59E0B22" }}>
            <Star size={18} style={{ color: "#F59E0B" }} fill="#F59E0B" />
          </div>
          <div className="flex-1">
            <p style={{ fontSize: 14, fontWeight: 600, color: TEXT }}>收藏</p>
            <p style={{ fontSize: 11, color: MUTED }}>已收藏的内容</p>
          </div>
          <ChevronRight size={16} style={{ color: DIM }} />
        </div>
        {/* Source groups */}
        {SRC_GROUPS.map(g => (
          <div key={g.id} className="mb-3 rounded-xl overflow-hidden" style={{ background: SURFACE }}>
            <button className="w-full flex items-center px-3.5 py-3.5" onClick={() => toggle(g.id)}>
              <span className="flex-1 text-left" style={{ fontSize: 14, fontWeight: 600, color: TEXT }}>{g.label}</span>
              <span style={{ fontSize: 12, color: MUTED, marginRight: 8 }}>{g.count}</span>
              {expanded.has(g.id)
                ? <ChevronUp size={15} style={{ color: DIM }} />
                : <ChevronDown size={15} style={{ color: DIM }} />}
            </button>
            {expanded.has(g.id) && g.items.map((item, i) => (
              <button key={i} onClick={() => onSrcTap(g)}
                className="w-full flex items-center px-3.5 py-2.5 gap-3"
                style={{ borderTop: `1px solid ${BORDER}` }}>
                <Av init={item.init} color={item.color} size={28} />
                <span className="flex-1 text-left overflow-hidden" style={{ fontSize: 13, color: TEXT, textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{item.name}</span>
                {item.unread && <div className="rounded-full flex-shrink-0" style={{ width: 8, height: 8, background: ACCENT }} />}
              </button>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Source detail screen ─────────────────────────────────────────────────────
function SrcDetailScreen({ group, onBack, onCardTap }: { group: SrcGroup; onBack: () => void; onCardTap: (c: Card) => void }) {
  const previewCards = D_CARDS.slice(0, 4);
  return (
    <div className="flex flex-col h-full">
      <StatusBar />
      <div className="flex items-center px-4 pt-1 pb-3 flex-shrink-0">
        <button onClick={onBack}><ChevronLeft size={24} style={{ color: TEXT }} /></button>
        <span className="ml-2 flex-1" style={{ fontSize: 17, fontWeight: 700, color: TEXT }}>{group.label}</span>
        <button><MoreHorizontal size={22} style={{ color: TEXT }} /></button>
      </div>
      <div className="flex-1 overflow-y-auto px-4 pt-1">
        <p className="mb-3" style={{ fontSize: 12, color: DIM }}>包含已读内容 · {group.count} 个订阅源</p>
        {previewCards.map(c => (
          <button key={c.id} onClick={() => onCardTap(c)}
            className="w-full text-left flex gap-3 py-3.5"
            style={{ borderBottom: `1px solid ${BORDER}` }}>
            {c.hasImg && (
              <div className="rounded-lg overflow-hidden flex-shrink-0" style={{ width: 72, height: 52, background: SURFACE2 }}>
                <CardImg img={c.img} unread={false} h={52} />
              </div>
            )}
            <div className="flex-1 min-w-0">
              <p className="mb-1.5" style={{ fontSize: 13.5, fontWeight: 500, color: TEXT, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>
                {c.title}
              </p>
              <div className="flex items-center gap-1.5">
                <Av init={c.srcInit} color={c.srcColor} size={15} />
                <span style={{ fontSize: 11, color: MUTED }}>{c.src}</span>
                <span style={{ fontSize: 11, color: DIM }}>{c.time}</span>
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── Settings screen ──────────────────────────────────────────────────────────
function SettingsScreen() {
  const [t, setT] = useState({ autoTranslate: true, autoSummary: true, openToRead: false, darkSystem: true, cloudSync: true });
  const tog = (k: keyof typeof t) => setT(prev => ({ ...prev, [k]: !prev[k] }));

  function Row({ label, sub, right, last }: { label: string; sub?: string; right: ReactNode; last?: boolean }) {
    return (
      <div className="flex items-center px-4 py-3.5" style={{ borderBottom: last ? "none" : `1px solid ${BORDER}` }}>
        <div className="flex-1 min-w-0 mr-3">
          <p style={{ fontSize: 14, color: TEXT }}>{label}</p>
          {sub && <p style={{ fontSize: 11, color: DIM, marginTop: 1.5 }}>{sub}</p>}
        </div>
        {right}
      </div>
    );
  }
  function Section({ title, children }: { title: string; children: ReactNode }) {
    return (
      <div className="mb-5">
        <p className="px-1 mb-2" style={{ fontSize: 11.5, color: DIM, fontWeight: 500, textTransform: "uppercase", letterSpacing: "0.06em" }}>{title}</p>
        <div className="rounded-xl overflow-hidden" style={{ background: SURFACE }}>{children}</div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <StatusBar />
      <div className="px-4 pt-1 pb-4 flex-shrink-0">
        <span style={{ fontSize: 17, fontWeight: 700, color: TEXT }}>设置</span>
      </div>
      <div className="flex-1 overflow-y-auto px-4">
        <Section title="AI">
          <Row label="自动翻译" sub="自动将外文文章和帖子翻译为中文" right={<Toggle on={t.autoTranslate} onToggle={() => tog("autoTranslate")} />} />
          <Row label="自动摘要" right={<Toggle on={t.autoSummary} onToggle={() => tog("autoSummary")} />} />
          <Row label="主题分类" right={<ChevronRight size={16} style={{ color: DIM }} />} />
          <Row label="推荐偏好" right={<ChevronRight size={16} style={{ color: DIM }} />} last />
        </Section>
        <Section title="阅读">
          <Row label="打开即标记已读" right={<Toggle on={t.openToRead} onToggle={() => tog("openToRead")} />} />
          <Row label="字体大小" right={
            <div className="flex items-center gap-1"><span style={{ fontSize: 13, color: MUTED }}>中</span><ChevronRight size={15} style={{ color: DIM }} /></div>
          } />
          <Row label="夜间模式随系统" right={<Toggle on={t.darkSystem} onToggle={() => tog("darkSystem")} />} last />
        </Section>
        <Section title="RSS">
          <Row label="导入 OPML" right={<ChevronRight size={16} style={{ color: DIM }} />} />
          <Row label="导出 OPML" right={<ChevronRight size={16} style={{ color: DIM }} />} />
          <Row label="RSSHub 配置" right={<ChevronRight size={16} style={{ color: DIM }} />} last />
        </Section>
        <Section title="同步">
          <Row label="云端同步" right={<Toggle on={t.cloudSync} onToggle={() => tog("cloudSync")} />} />
          <Row label="同步频率" right={
            <div className="flex items-center gap-1"><span style={{ fontSize: 13, color: MUTED }}>30 分钟</span><ChevronRight size={15} style={{ color: DIM }} /></div>
          } last />
        </Section>
      </div>
    </div>
  );
}

// ─── Article detail screen ────────────────────────────────────────────────────
function ArticleScreen({ card, onBack }: { card: Card; onBack: () => void }) {
  const [view, setView] = useState<"zh" | "orig">("zh");
  const showToggle = card.translated;
  const body = (view === "zh" ? card.zh : card.orig) ?? "";

  return (
    <div className="flex flex-col h-full">
      <StatusBar />
      <div className="flex items-center justify-between px-4 pt-1 pb-3 flex-shrink-0">
        <button onClick={onBack}><ChevronLeft size={24} style={{ color: TEXT }} /></button>
        <div className="flex items-center gap-4">
          <button><Bookmark size={20} style={{ color: TEXT }} /></button>
          <button><MoreHorizontal size={20} style={{ color: TEXT }} /></button>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto px-4 pb-8">
        {card.hasImg && (
          <div className="w-full rounded-xl overflow-hidden mb-4" style={{ height: 180 }}>
            <CardImg img={card.img} unread={false} h={180} />
          </div>
        )}
        {/* Translation toggle */}
        {showToggle && (
          <div className="inline-flex rounded-lg overflow-hidden mb-4" style={{ background: SURFACE2 }}>
            {(["zh", "orig"] as const).map(v => (
              <button key={v} onClick={() => setView(v)}
                className="px-4 py-1.5"
                style={{ fontSize: 13, fontWeight: v === view ? 600 : 400, background: v === view ? ACCENT : "transparent", color: v === view ? "white" : MUTED }}>
                {v === "zh" ? "译文" : "原文"}
              </button>
            ))}
          </div>
        )}
        {/* Source */}
        <div className="flex items-center gap-2.5 mb-3">
          <Av init={card.srcInit} color={card.srcColor} size={28} />
          <div>
            <p style={{ fontSize: 13, fontWeight: 500, color: TEXT }}>{card.src}</p>
            <p style={{ fontSize: 11, color: DIM }}>{card.time} 前</p>
          </div>
        </div>
        {/* Title */}
        <h2 style={{ fontSize: 19, fontWeight: 700, color: TEXT, lineHeight: 1.4, marginBottom: 14 }}>{card.title}</h2>
        {/* AI badge */}
        {showToggle && view === "zh" && (
          <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md mb-4" style={{ background: ACCENT + "1A" }}>
            <Sparkles size={11} style={{ color: ACCENT }} />
            <span style={{ fontSize: 11, color: ACCENT, fontWeight: 500 }}>AI 翻译</span>
          </div>
        )}
        {/* Body */}
        {body.split("\n\n").map((p, i) => (
          <p key={i} style={{ fontSize: 15, color: TEXT, lineHeight: 1.8, marginBottom: 16 }}>{p}</p>
        ))}
      </div>
    </div>
  );
}

// ─── App root ─────────────────────────────────────────────────────────────────
export default function App() {
  const [screen, setScreen] = useState<Scr>("home");
  const [aiMode, setAiMode] = useState<AIMode>("default");
  const [showSheet, setShowSheet] = useState(false);
  const [aiQuery, setAiQuery] = useState("");
  const [activeTab, setActiveTab] = useState(0);
  const [selectedCard, setSelectedCard] = useState<Card | null>(null);
  const [selectedGroup, setSelectedGroup] = useState<SrcGroup | null>(null);
  const [readIds, setReadIds] = useState<Set<string>>(new Set());

  const markRead = (id: string) => setReadIds(prev => new Set([...prev, id]));

  const handleCardTap = (c: Card) => {
    markRead(c.id);
    setSelectedCard(c);
    setScreen("article");
  };

  const handleGenerate = () => {
    setShowSheet(false);
    setAiMode("filtered");
    setActiveTab(0);
  };

  const handleReset = () => {
    setAiMode("default");
    setAiQuery("");
    setActiveTab(0);
  };

  const handleSrcTap = (g: SrcGroup) => {
    setSelectedGroup(g);
    setScreen("src-detail");
  };

  const handleNav = (s: NavId) => {
    const map: Record<NavId, Scr> = { home: "home", subs: "subs", settings: "settings" };
    setScreen(map[s]);
  };

  const navActive: NavId =
    screen === "subs" || screen === "src-detail" ? "subs" :
    screen === "settings" ? "settings" : "home";

  return (
    <div className="min-h-screen flex items-center justify-center"
      style={{ background: "#020203", fontFamily: "'Inter', system-ui, -apple-system, sans-serif" }}>
      <div className="relative flex flex-col overflow-hidden w-full sm:w-[390px] h-screen sm:h-[844px] sm:rounded-[44px]"
        style={{ background: BG, boxShadow: "0 0 0 6px #1a1a1a, 0 60px 120px rgba(0,0,0,0.9)" }}>

        {/* Main content area — position: relative so the sheet overlays it, not the nav */}
        <div className="flex-1 overflow-hidden relative flex flex-col">
          {screen === "home" && (
            <HomeScreen
              aiMode={aiMode} aiQuery={aiQuery} activeTab={activeTab} readIds={readIds}
              onAIFilter={() => setShowSheet(true)}
              onSearch={() => setScreen("search")}
              onCardTap={handleCardTap}
              onTopicChange={setActiveTab}
              onEdit={() => setShowSheet(true)}
              onReset={handleReset}
            />
          )}
          {screen === "search" && <SearchScreen onBack={() => setScreen("home")} />}
          {screen === "subs" && <SubsScreen onSrcTap={handleSrcTap} />}
          {screen === "src-detail" && selectedGroup && (
            <SrcDetailScreen group={selectedGroup} onBack={() => setScreen("subs")} onCardTap={handleCardTap} />
          )}
          {screen === "settings" && <SettingsScreen />}
          {screen === "article" && selectedCard && (
            <ArticleScreen card={selectedCard} onBack={() => setScreen("home")} />
          )}

          {/* AI Filter Sheet — overlays content but not bottom nav */}
          {screen === "home" && (
            <AIFilterSheet
              open={showSheet}
              query={aiQuery}
              onQueryChange={setAiQuery}
              onClose={() => setShowSheet(false)}
              onGenerate={handleGenerate}
            />
          )}
        </div>

        {/* Bottom nav — always below sheet */}
        {screen !== "article" && (
          <BottomNav active={navActive} onChange={handleNav} />
        )}
      </div>
    </div>
  );
}
