
  # Untitled

  This is a code bundle for Untitled. The original project is available at https://www.figma.com/design/MYYJ0fb0LAJjO9HNd8Q7n7/Untitled.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  